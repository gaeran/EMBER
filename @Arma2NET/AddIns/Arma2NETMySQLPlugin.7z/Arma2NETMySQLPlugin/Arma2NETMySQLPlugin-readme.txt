This development version of Arma2NETMySQLPlugin.dll is not signed. In order to use please put Arma2NET in development mode using the startup switch -arma2netdev
Build versions of this plugin can be found here: https://github.com/firefly2442/Arma2NETMySQLPlugin 

changelog

10/08/2012
- compiled against Arma2Net 2.11.1
- logs now save to AppData/Local/Arma2NETMySQL 

02/07/2012
- refactor some code so that we have a common startup regardless if you are using procedures or straight mysql calls
- use version number as specified by the project
- set appropriate version number

25/06/2012
- compiled against Arma2Net 1.11.1 Arma2Net.Managed
- Added ability to run straight MySQL commands.

23/06/2012
- Fixed duplicate entries in database.

22/06/2012
-  compiled against the 6.5.4 MySQL.Data Reference

16/06/2012
- fixed printing of messages in valid format

14/06/2012 
- Shows version number of Arma2NET that it is compiled with. 
- Fixed so it works with the latest version of the MySQL Connector (6.5.4). 
- Works with latest Arma2NET (1.10).

